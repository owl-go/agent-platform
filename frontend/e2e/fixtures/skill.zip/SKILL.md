---
name: e2e-skill
description: Local end-to-end fixture
---

# Test Skill
Read input and provide a concise report.
